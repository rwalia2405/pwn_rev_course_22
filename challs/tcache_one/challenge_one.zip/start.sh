#!/bin/sh
cd /pwn
./chall